// #if !UNITY_5_3_OR_NEWER
// using com.IvanMurzak.ReflectorNet.Model.Unity;
// using ModelContextProtocol.Protocol;
// using ModelContextProtocol.Server;
// using System.ComponentModel;
// using System.Threading.Tasks;

// namespace com.IvanMurzak.Unity.MCP.Server.API
// {
//     public partial class Tool_GameObject
//     {
//         [McpServerTool
//         (
//             Name = "GameObject_Find",
//             Title = "Find GameObject in opened Prefab or in a Scene"
//         )]
//         [Description(@"Finds specific GameObject by provided information.
// First it looks for the opened Prefab, if any Prefab is opened it looks only there ignoring a scene.
// If no opened Prefab it looks into current active scene.
// Returns GameObject information and its children.
// Also, it returns Components preview just for the target GameObject.")]
//         public ValueTask<CallToolResult> Find
//         (
//             GameObjectRef gameObjectRef,
//             [Description("Determines the depth of the hierarchy to include. 0 - means only the target GameObject. 1 - means to include one layer below.")]
//             int includeChildrenDepth = 0,
//             [Description("If true, it will print only brief data of the target GameObject.")]
//             bool briefData = false
//         )
//         {
//             return ToolRouter.Call("GameObject_Find", arguments =>
//             {
//                 arguments[nameof(gameObjectRef)] = gameObjectRef;
//                 arguments[nameof(includeChildrenDepth)] = includeChildrenDepth;
//                 arguments[nameof(briefData)] = briefData;
//             });
//         }
//     }
// }
// #endif